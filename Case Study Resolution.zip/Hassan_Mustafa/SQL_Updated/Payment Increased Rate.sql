
WITH MergedData AS (
    SELECT
        o.*,
        d.iso_date
    FROM
        fct_order o
    JOIN
        dim_date d
    ON
        o.order_time = d.iso_date
),

OrderAmounts AS (
    SELECT
        order_id,
        analytical_customer_id,
        gmv_amount_lc AS order_amount,
        LAG(gmv_amount_lc) OVER (PARTITION BY analytical_customer_id ORDER BY iso_date) AS previous_order_amount
    FROM
        MergedData
),

PaidMoreOrders AS (
    SELECT
        order_id,
        analytical_customer_id
    FROM
        OrderAmounts
    WHERE
        previous_order_amount IS NOT NULL
        AND order_amount > previous_order_amount
)

SELECT
    COUNT(DISTINCT order_id) AS num_orders_paid_more
FROM
    PaidMoreOrders;


//
num_orders_paid_more: 48228
//