WITH MergedData AS (
    SELECT
        o.*,
        d.iso_date
    FROM
        fct_order o
    JOIN
        dim_date d
    ON
        o.order_time = d.iso_date
),
DecemberOrders AS (
    SELECT
        *
    FROM
        MergedData
    WHERE
        iso_date BETWEEN '2021-12-01' AND '2021-12-31'
),

NovemberCustomers AS (
    SELECT DISTINCT
        o.analytical_customer_id
    FROM
        MergedData o
    JOIN
        dim_date d
    ON
        o.order_time = d.iso_date
    WHERE
        d.iso_date BETWEEN '2021-11-01' AND '2021-11-30'
),
ChurnedCustomers AS (
    SELECT DISTINCT
        n.analytical_customer_id
    FROM
        NovemberCustomers n
    LEFT JOIN
        DecemberOrders d
    ON
        n.analytical_customer_id = d.analytical_customer_id
    WHERE
        d.analytical_customer_id IS NULL
),

CustomerOrders AS (
    SELECT
        o.analytical_customer_id,
        MONTH(d.iso_date) AS order_month,
        COUNT(o.order_id) AS order_count
    FROM
        MergedData o
    JOIN
        dim_date d
    ON
        o.order_time = d.iso_date
    WHERE
        d.iso_date BETWEEN '2021-09-01' AND '2021-11-30'
        AND o.analytical_customer_id IN (SELECT analytical_customer_id FROM ChurnedCustomers)
    GROUP BY
        o.analytical_customer_id, MONTH(d.iso_date)
),
CategorizedCustomers AS (
    SELECT DISTINCT
        c.analytical_customer_id,
        CASE
            WHEN SUM(order_count) >= 12 AND COUNT(order_month) = 3 THEN 'Frequent & Consistent'
            WHEN SUM(order_count) >= 12 THEN 'Frequent'
            WHEN COUNT(order_month) = 3 THEN 'Consistent'
            ELSE 'Neither'
        END AS customer_group
    FROM
        CustomerOrders c
    GROUP BY
        c.analytical_customer_id
),

CategoryCounts AS (
    SELECT
        customer_group AS Category,
        COUNT(analytical_customer_id) AS Count
    FROM
        CategorizedCustomers
    GROUP BY
        customer_group
)

SELECT
    *
FROM
    CategoryCounts;

//
Category		Count
Consistent		576
Frequent		29
Frequent & Consistent	152
Neither			1780
//