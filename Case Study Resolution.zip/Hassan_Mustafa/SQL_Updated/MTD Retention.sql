WITH CustomerRetention AS (
    SELECT DISTINCT
        analytical_customer_id,
        year_month_str
    FROM
        fct_order
    WHERE
        is_successful = 1
)
SELECT
    [Date],
    SUM(CASE WHEN year_month_str = '2021-02' THEN 1 ELSE 0 END) * 100.0 / COUNT(DISTINCT analytical_customer_id) AS MTDRetentionRate
FROM (
    SELECT DISTINCT
        o.iso_date AS [Date],
        c.analytical_customer_id,
        c.year_month_str
    FROM
        dim_date AS d
    CROSS JOIN
        CustomerRetention AS c
    LEFT JOIN
        fct_order AS o
    ON
        o.iso_date BETWEEN DATEFROMPARTS(d.year, d.month, 1) AND EOMONTH(DATEFROMPARTS(d.year, d.month, 1))
) AS DateCustomer
GROUP BY
    [Date]
ORDER BY
    [Date];
