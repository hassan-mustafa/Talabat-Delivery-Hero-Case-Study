WITH MergedData AS (
    SELECT
        O.order_id,
        O.analytical_customer_id,
        O.order_time,
        ROW_NUMBER() OVER (ORDER BY O.order_time) AS day_number,
        O.is_successful
    FROM
        fct_order O
    WHERE
        O.is_successful = 'TRUE'
),
MTDActiveCustomers AS (
    SELECT
        order_time,
        COUNT(DISTINCT analytical_customer_id) AS MTD_customers
    FROM
        MergedData
    GROUP BY
        order_time
)
SELECT
    MONTH(order_time) AS date,
    MTD_customers
FROM
    MTDActiveCustomers
WHERE 
	DAY(order_time) = 30;

//
Month MTD_customers
9	803
10	745
11	710
12	691
//